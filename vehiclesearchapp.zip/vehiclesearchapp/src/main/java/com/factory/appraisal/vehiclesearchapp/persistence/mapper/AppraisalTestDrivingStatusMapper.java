package com.factory.appraisal.vehiclesearchapp.persistence.mapper;


import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraisalTestDriveStatus;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraisalTestDriveStatus;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface AppraisalTestDrivingStatusMapper {
    AppraisalVehicleMapper INSTANCE1 = Mappers.getMapper( AppraisalVehicleMapper.class);
    AppraisalVehicleAcConditionMapper INSTANCE2 = Mappers.getMapper(AppraisalVehicleAcConditionMapper.class);
    AppraisalVehicleInteriorConditionMapper INSTANCE3 = Mappers.getMapper(AppraisalVehicleInteriorConditionMapper.class);
    AppraisalVehicleOilConditionMapper INSTANCE4 = Mappers.getMapper(AppraisalVehicleOilConditionMapper.class);
    AppraisalVehicleStereoStatusMapper INSTANCE5 = Mappers.getMapper(AppraisalVehicleStereoStatusMapper.class);


    @Mapping(target = "appraisalRef",ignore = true)
    @Mapping(target = "appraisalVehicleAcCondition",ignore = true)
    @Mapping(target = "appraisalVehicleInteriorCondition",ignore = true)
    @Mapping(target = "appraisalVehicleOilCondition",ignore = true)
    @Mapping(target = "appraisalVehicleStereoStatus",ignore = true)
    AppraisalTestDriveStatus modelToDto(EAppraisalTestDriveStatus eAppraisalTestDrivingStatus);  //ignore  due to  recursion problem in mapstruct, entities having bidirectional relationship

    @Mapping(target ="appraisalRef",expression = "java( mapAppraisalRef(appraisalTestDrivingStatus.getAppraisalRef()))")
    @Mapping(target ="appraisalRef.appraisalTestDriveStatus",ignore = true)


    @Mapping(target ="appraisalVehicleAcCondition",expression = "java( mapAppraisalVehicleAcCondition(appraisalTestDrivingStatus.getAppraisalVehicleAcCondition()))")
    @Mapping(target ="appraisalVehicleAcCondition.vehicleStatus",ignore = true)

    @Mapping(target ="appraisalVehicleInteriorCondition",expression = "java( mapAppraisalVehicleInteriorCondition(appraisalTestDrivingStatus.getAppraisalVehicleInteriorCondition()))")
    @Mapping(target ="appraisalVehicleInteriorCondition.vehicleStatus",ignore = true)

    @Mapping(target ="appraisalVehicleOilCondition",expression = "java(  mapAppraisalVehicleOilCondition(appraisalTestDrivingStatus.getAppraisalVehicleOilCondition()))")
    @Mapping(target ="appraisalVehicleOilCondition.vehicleStatus",ignore = true)

    @Mapping(target ="appraisalVehicleStereoStatus",expression = "java( mapAppraisalVehicleStereoStatus(appraisalTestDrivingStatus.getAppraisalVehicleStereoStatus()))")
    @Mapping(target ="appraisalVehicleStereoStatus.vehicleStatus",ignore = true)

    EAppraisalTestDriveStatus dtoToModel(AppraisalTestDriveStatus appraisalTestDrivingStatus);



}
