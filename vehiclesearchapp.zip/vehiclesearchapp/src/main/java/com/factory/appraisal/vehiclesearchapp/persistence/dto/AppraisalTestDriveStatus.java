package com.factory.appraisal.vehiclesearchapp.persistence.dto;



import com.factory.appraisal.vehiclesearchapp.persistence.model.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


import javax.validation.constraints.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class AppraisalTestDriveStatus extends TransactionEntity {

    private Long vehicleDivingStatusId;
    private AppraiseVehicle appraisalRef;

    private AppraisalVehicleAcCondition appraisalVehicleAcCondition;

    private AppraisalVehicleInteriorCondition appraisalVehicleInteriorCondition;
    private AppraisalVehicleOilCondition appraisalVehicleOilCondition;
    private AppraisalVehicleStereoStatus appraisalVehicleStereoStatus;
    private AppraisalVehicleTireCondition appraisalVehicleTireCondition;
    private VehicleDrivingWarnLightStatus vehicleDrivingWarnLightStatus;


    @Max(value = 50,message = "Maximum 50 characters are allowed")
    private String optionalEquipment;
    @Max(value=4,message = "Maximum 4 characters are allowed")
    @NotNull(message = "Engine Type shouldn't be empty")
    private String  engineType;
    @Max(value=10,message = "Maximum 10 characters are allowed")
    @NotNull(message = "Transmission Type shouldn't be empty")
    private String transmissionType;
    @Max(value=5,message = "Maximum 5 characters are allowed")
    @NotNull(message = "Steering shouldn't be empty")
    private String steering;
    @Max(value=30,message = "Maximum 30 characters are allowed")
    private String doorLockType;
    @Max(value=17,message = "Maximum 17 characters are allowed")
    private String  frontLeftSideImage;
    @Max(value=15,message = "Maximum 15 characters are allowed")
    @NotNull(message = "Front Left Window Status shouldn't be empty")
    private String frontLeftWindowStatus;
    @Max(value=15,message = "Maximum 15 characters are allowed")
    @NotNull(message = "Front Right Window Status shouldn't be empty")
    private String   frontRightWindowStatus;
    @Max(value=15,message = "Maximum 15 characters are allowed")
    @NotNull(message = "Rear Left Window Status shouldn't be empty")
    private String  rearLeftWindowStatus;
    @Max(value=15,message = "Maximum 15 characters are allowed")
    @NotNull(message = "Rear Right Window Status shouldn't be empty")
    private String  rearRightWindowStatus;
    @Max(value=17,message = "Maximum 17 characters are allowed")
    @NotNull(message = "Front Right Image shouldn't be empty")
    private String frontRightImage;
    @Max(value=17,message = "Maximum 17 characters are allowed")
    @NotNull(message = "Rear Left Image shouldn't be empty")
    private String  rearLeftImage;
    @Max(value=17,message = "Maximum 17 characters are allowed")
    @NotNull(message = "Rear Right Image shouldn't be empty")
    private String rearRightImage;
    @Max(value=30,message = "Maximum 30 characters are allowed")
    @NotNull(message = "Interior Type shouldn't be empty")
    private String interiorType;
    @Max(value=30,message = "Maximum 30 characters are allowed")
    private String lightCondition;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String roofType;
    @Max(value=10,message = "Maximum 10 characters are allowed")
    private String appraisalFollowUp;
    @Max(value=10,message = "Maximum 10 characters are allowed")
    private String appraisalInventoryStatus;
    @Max(value=10,message = "Maximum 10 characters are allowed")
    private String exteriorColor;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String exteriorDamageStatus;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String frontDriverSideDamageDescription;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String frontDriverSideDamageStatus;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String frontPassengerSideDamageDescription;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String frontPassengerSideDamageStatus;

    // private String optionalEquipment;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String paintWorkFrontDriverSideStatus;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String paintWorkFrontDriverSideStatusDescription;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String paintWorkFrontPassengerSideStatus;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String paintWorkFrontPassengerSideStatusDescription;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String paintWorkRearDriverSideStatus;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String paintWorkRearDriverSideStatusDescription;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String paintWorkRearPassengerSideStatus;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String paintWorkRearPassengerSideStatusDescription;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String paintWorkStatus;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String rearDriverSideDamageDescription;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String rearDriverSideDamageStatus;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String rearPassengerSideDamageDescription;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String rearPassengerSideDamageStatus;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String wholesaleBuyFiguresStatus;
    @Max(value=50,message = "Maximum 50 characters are allowed")
    private String windshieldDamage;

}
