package com.factory.appraisal.vehiclesearchapp.persistence.mapper;


import com.factory.appraisal.vehiclesearchapp.persistence.dto.*;
import com.factory.appraisal.vehiclesearchapp.persistence.model.*;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AppraisalVehicleMapper {

    AppraisalTestDrivingStatusMapper INSTANCE = Mappers.getMapper(AppraisalTestDrivingStatusMapper.class);
    @Mapping(target = "appraisalTestDriveStatus",ignore = true)

    AppraiseVehicle modelToDto(EAppraiseVehicle eAppraiseVehicle);
    @Mapping(target ="appraisalTestDriveStatus",expression = "java(mapAppraisalTestDriveStatus(appraiseVehicle.getAppraisalTestDriveStatus()))")
    EAppraiseVehicle dtoToModel(AppraiseVehicle appraiseVehicle);

    List<EAppraiseVehicle> dtosToModels(List<AppraiseVehicle> appraiseVehicleList);

    List<AppraiseVehicle> modelsToDtos(List<EAppraiseVehicle> eAppraiseVehicleList);

    default EAppraisalTestDriveStatus mapAppraisalTestDriveStatus(AppraisalTestDriveStatus appraisalTestDriveStatusDto){
        return INSTANCE.dtoToModel(appraisalTestDriveStatusDto);
    }




}
