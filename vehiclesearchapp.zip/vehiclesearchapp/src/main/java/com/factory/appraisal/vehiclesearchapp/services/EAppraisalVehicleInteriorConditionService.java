package com.factory.appraisal.vehiclesearchapp.services;

//kalyan

public interface EAppraisalVehicleInteriorConditionService {



}
