package com.factory.appraisal.vehiclesearchapp.services.impl;


import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.AppraisalTestDrivingStatusMapper;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.AppraisalVehicleAcConditionMapper;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.AppraisalVehicleMapper;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;


import com.factory.appraisal.vehiclesearchapp.repository.EAppraisalTestDriveStatusRepo;
import com.factory.appraisal.vehiclesearchapp.repository.EAppraiseVehicleRepo;
import com.factory.appraisal.vehiclesearchapp.services.EAppraiseVehicleService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@Service
public class EAppraiseVehicleServiceImpl implements EAppraiseVehicleService {
    @Autowired
    EAppraisalTestDriveStatusRepo eAppraisalTestDriveStatusRepo;

    @Autowired
    EAppraiseVehicleRepo eAppraiseVehicleRepo;

    @Autowired
    private AppraisalVehicleMapper appraisalVehicleMapper;
    @Autowired
    private AppraisalVehicleAcConditionMapper acConditionMapper;
    @Autowired
    private AppraisalTestDrivingStatusMapper appraisalTestDrivingStatusMapper;


    @Override
    public List<AppraiseVehicle> GetAppraisals(Integer pageNumber, Integer pageSize) {
        Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by("createdOn").descending());
        Page<EAppraiseVehicle> pageResult = eAppraiseVehicleRepo.findAllByValidIsTrueOrderByCreatedOnDesc(pageable);

        List<EAppraiseVehicle> apv = pageResult.toList();

        List<AppraiseVehicle> appraiseVehicleDtos = appraisalVehicleMapper.modelsToDtos(apv);

        ArrayList<EAppraiseVehicle> al1 = new ArrayList<>(apv);
        ArrayList<AppraiseVehicle> al2 = new ArrayList<>(appraiseVehicleDtos);
        for (int i = 0; i < al1.size(); i++) {
            al2.get(i).setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(al1.get(i).getAppraisalTestDriveStatus()));
        }

        List<AppraiseVehicle> appraiseVehicleDtos1 = al2;
        return appraiseVehicleDtos1;
    }

    private final String FOLDER_PATH = "C:/Users/kalya/Desktop/rupesh/";


    @Override
    public AppraiseVehicle addAppraiseVehicle(AppraiseVehicle appraiseVehicle, MultipartFile frontLeftSideImage) throws IOException {
        EAppraiseVehicle eAppraiseVehicle = appraisalVehicleMapper.dtoToModel(appraiseVehicle);

        String extension = FilenameUtils.getExtension(frontLeftSideImage.getOriginalFilename());
        String filename = UUID.randomUUID().toString() + "." + extension;
        Path filePath = Paths.get(FOLDER_PATH + filename);

        Files.write(filePath, frontLeftSideImage.getBytes()); //sending to folder
        eAppraiseVehicle.getAppraisalTestDriveStatus().setFrontLeftSideImage(filename);

        eAppraiseVehicle.setAppraisalTestDriveStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());
        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalRef(eAppraiseVehicle);


        EAppraiseVehicle eAppraiseVehicle1 = eAppraiseVehicleRepo.save(eAppraiseVehicle);//4
        // eAppraisalTestDriveStatusRepo.save(eAppraiseVehicle.getAppraisalTestDriveStatus());//5


        return appraisalVehicleMapper.modelToDto(eAppraiseVehicle);
    }

    @Override
    public ResponseEntity<byte[]> findByVinNumber(String vinNum) throws IOException {
        EAppraiseVehicle apv = eAppraiseVehicleRepo.findByVinNumberAndValidIsTrue(vinNum);
        if (apv != null) {

            AppraiseVehicle appraiseVehicleDto = appraisalVehicleMapper.modelToDto(apv);

            appraiseVehicleDto.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(apv.getAppraisalTestDriveStatus()));


            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.modelToDto(apv.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));

            //finding image
            String filePath = FOLDER_PATH + appraiseVehicleDto.getAppraisalTestDriveStatus().getRearRightImage();
            byte[] image = Files.readAllBytes(new File(filePath).toPath());

            //loading object and file to map
            Map<String, Object> data = new HashMap<>();
            data.put("object", appraiseVehicleDto);
            data.put("file", image);
//             you can add more images here        data.put("file2",image2);

            // Return the map as JSON

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            return new ResponseEntity<>(new ObjectMapper().writeValueAsBytes(data), headers, HttpStatus.OK);


        } else throw new RuntimeException("Did not find AppraisalVehicle of  - " + vinNum);
    }

    @Override
    public AppraiseVehicle updateAppraisalVehicle(AppraiseVehicle eAppraiseVehicledto, MultipartFile frontLeftSideImage) throws IOException {
        EAppraiseVehicle vehicle = eAppraiseVehicleRepo.findByVinNumber(eAppraiseVehicledto.getVinNumber());
        if (vehicle != null) {

            if (eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalRef() == null) {

                eAppraiseVehicledto.getAppraisalTestDriveStatus().setAppraisalRef(appraisalVehicleMapper.modelToDto(vehicle));

            }

            if (eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition().getVehicleStatus() == null) {

                eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition().setVehicleStatus(eAppraiseVehicledto.getAppraisalTestDriveStatus());
            }


            //add new file
            String extension = FilenameUtils.getExtension(frontLeftSideImage.getOriginalFilename());
            String filename = UUID.randomUUID().toString() + "." + extension;
            Path filePath = Paths.get(FOLDER_PATH + filename);


            Files.write(filePath, frontLeftSideImage.getBytes()); //sending to folder

            //delete old file
            String old = FOLDER_PATH + vehicle.getAppraisalTestDriveStatus().getFrontLeftSideImage();
            Path filePathOld = Paths.get(old);
            Files.delete(filePathOld);


            eAppraiseVehicledto.getAppraisalTestDriveStatus().setFrontLeftSideImage(filename);      //setting to object


            vehicle.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus()));
            vehicle.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));

            eAppraiseVehicleRepo.save(vehicle);

            AppraiseVehicle appraiseVehicleDto = appraisalVehicleMapper.modelToDto(vehicle);

            appraiseVehicleDto.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(vehicle.getAppraisalTestDriveStatus()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.modelToDto(vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));


            return appraiseVehicleDto;

        } else throw new RuntimeException("Did not find AppraisalVehicle of " + eAppraiseVehicledto.getVinNumber());
    }

    @Override
    public String deleteAppraisalVehicle(String vinNum) {
        EAppraiseVehicle byVinNumber = eAppraiseVehicleRepo.findByVinNumber(vinNum);
        if (byVinNumber != null) {
            byVinNumber.setValid(false);
            eAppraiseVehicleRepo.save(byVinNumber);

            return "deleted";
        } else
            throw new RuntimeException("Did not find AppraisalVehicle of  - " + vinNum);
    }
}


