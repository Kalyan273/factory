package com.factory.appraisal.vehiclesearchapp.services.impl;
//kalyan


import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.*;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;


import com.factory.appraisal.vehiclesearchapp.repository.EAppraisalTestDriveStatusRepo;
import com.factory.appraisal.vehiclesearchapp.repository.EAppraiseVehicleRepo;
import com.factory.appraisal.vehiclesearchapp.services.EAppraiseVehicleService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@Service
public class EAppraiseVehicleServiceImpl implements EAppraiseVehicleService {
    @Autowired
    EAppraisalTestDriveStatusRepo eAppraisalTestDriveStatusRepo;

    @Autowired
    EAppraiseVehicleRepo eAppraiseVehicleRepo;

    @Autowired
    private AppraisalVehicleMapper appraisalVehicleMapper;

    @Autowired
    private AppraisalVehicleInteriorConditionMapper interiorConditionMapper;

    @Autowired
    private AppraisalVehicleOilConditionMapper oilConditionMapper ;

    @Autowired
    private AppraisalVehicleStereoStatusMapper stereoStatusMapper;

    @Autowired
    private AppraisalVehicleAcConditionMapper acConditionMapper;
    @Autowired
    private AppraisalTestDrivingStatusMapper appraisalTestDrivingStatusMapper;


    @Override
    public List<AppraiseVehicle> GetAppraisals(Integer pageNumber, Integer pageSize) {
        Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by("createdOn").descending());
        Page<EAppraiseVehicle> pageResult = eAppraiseVehicleRepo.findAllByValidIsTrueOrderByCreatedOnDesc(pageable);

        List<EAppraiseVehicle> apv = pageResult.toList();

        List<AppraiseVehicle> appraiseVehicleDtos = appraisalVehicleMapper.modelsToDtos(apv);

        ArrayList<EAppraiseVehicle> al1 = new ArrayList<>(apv);
        ArrayList<AppraiseVehicle> al2 = new ArrayList<>(appraiseVehicleDtos);
        for (int i = 0; i < al1.size(); i++) {
            al2.get(i).setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(al1.get(i).getAppraisalTestDriveStatus()));
        }

        List<AppraiseVehicle> appraiseVehicleDtos1 = al2;
        return appraiseVehicleDtos1;
    }

    private final String FOLDER_PATH = "C:/Users/kalya/Desktop/rupesh/";


    @Override
    public AppraiseVehicle addAppraiseVehicle(AppraiseVehicle appraiseVehicle, MultipartFile frontLeftSideImage) throws IOException {
        EAppraiseVehicle eAppraiseVehicle = appraisalVehicleMapper.dtoToModel(appraiseVehicle);

        String extension = FilenameUtils.getExtension(frontLeftSideImage.getOriginalFilename());
        String filename = UUID.randomUUID().toString() + "." + extension;
        Path filePath = Paths.get(FOLDER_PATH + filename);

        Files.write(filePath, frontLeftSideImage.getBytes()); //sending to folder
        eAppraiseVehicle.getAppraisalTestDriveStatus().setFrontLeftSideImage(filename);

        eAppraiseVehicle.setAppraisalTestDriveStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());
        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalRef(eAppraiseVehicle);


        EAppraiseVehicle eAppraiseVehicle1 = eAppraiseVehicleRepo.save(eAppraiseVehicle);//4
        // eAppraisalTestDriveStatusRepo.save(eAppraiseVehicle.getAppraisalTestDriveStatus());//5


        return appraisalVehicleMapper.modelToDto(eAppraiseVehicle);
    }

    @Override
    public ResponseEntity<byte[]> findByVinNumber(String vinNum) throws IOException {
        EAppraiseVehicle apv = eAppraiseVehicleRepo.findByVinNumberAndValidIsTrue(vinNum);
        if (apv != null) {

            AppraiseVehicle appraiseVehicleDto = appraisalVehicleMapper.modelToDto(apv);

            appraiseVehicleDto.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(apv.getAppraisalTestDriveStatus()));


            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.modelToDto(apv.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleInteriorCondition(interiorConditionMapper.modelToDto(apv.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleOilCondition(oilConditionMapper.modelToDto(apv.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleStereoStatus(stereoStatusMapper.modelToDto(apv.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus()));
            //finding image
            String filePath = FOLDER_PATH + appraiseVehicleDto.getAppraisalTestDriveStatus().getRearRightImage();
            byte[] image = Files.readAllBytes(new File(filePath).toPath());

            //loading object and file to map
            Map<String, Object> data = new HashMap<>();
            data.put("object", appraiseVehicleDto);
            data.put("file", image);
//             you can add more images here        data.put("file2",image2);

            // Return the map as JSON

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            return new ResponseEntity<>(new ObjectMapper().writeValueAsBytes(data), headers, HttpStatus.OK);


        } else throw new RuntimeException("Appraisal Vehicle not found with VinNumber : " + vinNum);
    }

    @Override
    public AppraiseVehicle updateAppraisalVehicle(AppraiseVehicle eAppraiseVehicledto, MultipartFile frontLeftSideImage) throws IOException {
        EAppraiseVehicle vehicle = eAppraiseVehicleRepo.findByVinNumber(eAppraiseVehicledto.getVinNumber());
        if (vehicle != null) {

            if (eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalRef() == null) {

                eAppraiseVehicledto.getAppraisalTestDriveStatus().setAppraisalRef(appraisalVehicleMapper.modelToDto(vehicle));

            }

            if (eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition().getVehicleStatus() == null) {

                eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition().setVehicleStatus(eAppraiseVehicledto.getAppraisalTestDriveStatus());
            }
            if (eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition().getVehicleStatus() == null) {

                eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition().setVehicleStatus(eAppraiseVehicledto.getAppraisalTestDriveStatus());
            }
            if (eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition().getVehicleStatus() == null) {

                eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition().setVehicleStatus(eAppraiseVehicledto.getAppraisalTestDriveStatus());
            }
            if (eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus().getVehicleStatus() == null) {

                eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus().setVehicleStatus(eAppraiseVehicledto.getAppraisalTestDriveStatus());
            }


            //add new file
            String extension = FilenameUtils.getExtension(frontLeftSideImage.getOriginalFilename());
            String filename = UUID.randomUUID().toString() + "." + extension;
            Path filePath = Paths.get(FOLDER_PATH + filename);


            Files.write(filePath, frontLeftSideImage.getBytes()); //sending to folder

            //delete old file
            String old = FOLDER_PATH + vehicle.getAppraisalTestDriveStatus().getFrontLeftSideImage();
            Path filePathOld = Paths.get(old);
            Files.delete(filePathOld);


            eAppraiseVehicledto.getAppraisalTestDriveStatus().setFrontLeftSideImage(filename);      //setting to object


            vehicle.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus()));
            vehicle.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));

            vehicle.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus()));
            vehicle.getAppraisalTestDriveStatus().setAppraisalVehicleInteriorCondition(interiorConditionMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition()));

            vehicle.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus()));
            vehicle.getAppraisalTestDriveStatus().setAppraisalVehicleOilCondition(oilConditionMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition()));

            vehicle.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus()));
            vehicle.getAppraisalTestDriveStatus().setAppraisalVehicleStereoStatus(stereoStatusMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus()));


            eAppraiseVehicleRepo.save(vehicle);

            AppraiseVehicle appraiseVehicleDto = appraisalVehicleMapper.modelToDto(vehicle);

            appraiseVehicleDto.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(vehicle.getAppraisalTestDriveStatus()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.modelToDto(vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));

            appraiseVehicleDto.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(vehicle.getAppraisalTestDriveStatus()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleInteriorCondition(interiorConditionMapper.modelToDto(vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition()));

            appraiseVehicleDto.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(vehicle.getAppraisalTestDriveStatus()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleOilCondition(oilConditionMapper.modelToDto(vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition()));

            appraiseVehicleDto.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(vehicle.getAppraisalTestDriveStatus()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleStereoStatus(stereoStatusMapper.modelToDto(vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus()));


            return appraiseVehicleDto;

        } else throw new RuntimeException("Appraisal Vehicle not found with VinNumber : " + eAppraiseVehicledto.getVinNumber());
    }

    @Override
    public String deleteAppraisalVehicle(String vinNum) {
        EAppraiseVehicle byVinNumber = eAppraiseVehicleRepo.findByVinNumber(vinNum);
        if (byVinNumber != null) {
            byVinNumber.setValid(false);
            eAppraiseVehicleRepo.save(byVinNumber);

            return "deleted";
        } else
            throw new RuntimeException("Appraisal Vehicle not found with VinNumber :" + vinNum);
    }
}


